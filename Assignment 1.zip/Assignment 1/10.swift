import Foundation

let coordinates2D = (x1: 3.5, y1: 4.5, x2: 1.5, y2: 2.5)
let x1 = coordinates2D.x1
let x2 = coordinates2D.x2
let y1 = coordinates2D.y1
let y2 = coordinates2D.y2
let distance = sqrt(((x2 - x1) * (x2 - x1)) + ((y2 - y1) * (y2 - y1)))
print(distance)
exercisesSolved = exercisesSolved + 1


