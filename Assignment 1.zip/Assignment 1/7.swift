let position: Int = 33
let row: Int = position / 8
let column: Int = position % 8
print(row)
print(column)
exercisesSolved = exercisesSolved + 1
