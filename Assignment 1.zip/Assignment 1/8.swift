let dividend: Double = 10
let divisor: Double = 4
let quotient = (dividend / divisor) 
let reminder = (dividend - divisor * (dividend / divisor)) 
print(quotient)
print(reminder)
exercisesSolved = exercisesSolved + 1


