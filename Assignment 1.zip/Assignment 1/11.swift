exercisesSolved = exercisesSolved + 1
print("Percentage of exercise is solved :", exercisesSolved / exercises)
