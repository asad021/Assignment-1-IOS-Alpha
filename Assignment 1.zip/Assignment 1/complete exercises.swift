import Foundation

//question 1
let exercises: Int = 11
var exercisesSolved: Int = 0
exercisesSolved = exercisesSolved + 1

//question 2

var age: Int = 16
print(age)
age = 30
print(age)
exercisesSolved = exercisesSolved + 1

//question 3
let a: Int = 46
let b: Int = 10
1//
let answer1: Int = (a * 100) + b
print(answer1)
2//
let answer2: Int = (a * 100) + (b * 100)
print(answer2)
3//
let answer3: Int = (a * 100) + (b / 10)
print(answer3)
exercisesSolved = exercisesSolved + 1

//question 4
let number: Int = ((5 * 3) - 4 / (2 * 2)) 
print(number)
exercisesSolved = exercisesSolved + 1

//question 5
let a1: Double = 9.87
let b1: Double = 7.37
let average: Double = (a1 + b1) / 2
print(average)
exercisesSolved = exercisesSolved + 1

//question 6
let fahrenheit: Double = 32
let celcius: Double = (fahrenheit - 32) * 5 / 9
print(celcius)
exercisesSolved = exercisesSolved + 1

//question 7
let position: Int = 33
let row: Int = position / 8
let column: Int = position % 8
print(row)
print(column)
exercisesSolved = exercisesSolved + 1

//question 8
let dividend: Double = 10
let divisor: Double = 4
let quotient = (dividend / divisor) 
let reminder = (dividend - divisor * (dividend / divisor)) 
print(quotient)
print(reminder)
exercisesSolved = exercisesSolved + 1

//question 9
let degrees: Double = 60
let radians: Double = degrees * (3.14 / 180) 
print("angle in \(radians) radians")
exercisesSolved = exercisesSolved + 1

//question 10
let coordinates2D = (x1: 3.5, y1: 4.5, x2: 1.5, y2: 2.5)
let x1 = coordinates2D.x1
let x2 = coordinates2D.x2
let y1 = coordinates2D.y1
let y2 = coordinates2D.y2
let distance = sqrt(((x2 - x1) * (x2 - x1)) + ((y2 - y1) * (y2 - y1)))
print(distance)
exercisesSolved = exercisesSolved + 1

//question 11
exercisesSolved = exercisesSolved + 1
print("Percentage of exxercise is solved :", exercisesSolved / exercises)
