let namedCoordinate = (row: 2, column: 3)
print(namedCoordinate.row)
print(namedCoordinate.column)
