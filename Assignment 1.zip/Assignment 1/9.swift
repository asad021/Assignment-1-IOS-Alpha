let degrees: Double = 60
let radians: Double = degrees * (3.14 / 180) 
print("angle in \(radians) radians")
exercisesSolved = exercisesSolved + 1

