let coordinate = (2, 3)
let x = coordinate.0
let y = coordinate.1
print(x)
print(y)
