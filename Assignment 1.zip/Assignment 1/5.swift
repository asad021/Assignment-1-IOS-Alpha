let a1: Double = 9.87
let b1: Double = 7.37
let average: Double = (a1+ b1) / 2
print(average)
exercisesSolved = exercisesSolved + 1
