let fahrenheit: Double = 32
let celcius: Double = (fahrenheit - 32) * (5 / 9)
print(celcius)
exercisesSolved = exercisesSolved + 1
