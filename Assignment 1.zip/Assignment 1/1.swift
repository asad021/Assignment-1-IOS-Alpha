let exercises: Int = 11
var exercisesSolved: Int = 0
exercisesSolved = exercisesSolved + 1