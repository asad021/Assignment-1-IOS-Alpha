var age: Int = 16
print(age)
age = 30
print(age)
exercisesSolved = exercisesSolved + 1
