let number: Int = ((5 * 3) - 4 / (2 * 2)) 
print(number)
exercisesSolved = exercisesSolved + 1
