let a: Int = 46
let b: Int = 10

1//
let answer1: Int = (a * 100) + b
print(answer1)

2//
let answer2: Int = (a * 100) + (b * 100)
print(answer2)

3//
let answer3: Int = (a * 100) + (b / 10)
print(answer3)
exercisesSolved = exercisesSolved + 1

